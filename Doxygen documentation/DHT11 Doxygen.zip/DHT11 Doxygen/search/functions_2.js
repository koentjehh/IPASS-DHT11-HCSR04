var searchData=
[
  ['start_5fand_5fread',['start_and_read',['../class_d_h_t11.html#a86b4384a312c5c83f09deed20780b8f7',1,'DHT11']]]
];
